// ===== 游戏配置文件（由 sync-config.py 从飞书表格自动生成）=====
// 修改飞书表格后运行同步脚本即可更新，请勿手动编辑此文件
// 最后同步: 2026-09-03 07:39:46

const GAME_CONFIG = {
  // 角色等级经验表（共 150 条）
  expTable: [
  {
    "level": 1,
    "exp": 10
  },
  {
    "level": 2,
    "exp": 13
  },
  {
    "level": 3,
    "exp": 16
  },
  {
    "level": 4,
    "exp": 19
  },
  {
    "level": 5,
    "exp": 23
  },
  {
    "level": 6,
    "exp": 27
  },
  {
    "level": 7,
    "exp": 31
  },
  {
    "level": 8,
    "exp": 35
  },
  {
    "level": 9,
    "exp": 39
  },
  {
    "level": 10,
    "exp": 44
  },
  {
    "level": 11,
    "exp": 49
  },
  {
    "level": 12,
    "exp": 54
  },
  {
    "level": 13,
    "exp": 59
  },
  {
    "level": 14,
    "exp": 64
  },
  {
    "level": 15,
    "exp": 70
  },
  {
    "level": 16,
    "exp": 76
  },
  {
    "level": 17,
    "exp": 82
  },
  {
    "level": 18,
    "exp": 88
  },
  {
    "level": 19,
    "exp": 94
  },
  {
    "level": 20,
    "exp": 101
  },
  {
    "level": 21,
    "exp": 108
  },
  {
    "level": 22,
    "exp": 115
  },
  {
    "level": 23,
    "exp": 122
  },
  {
    "level": 24,
    "exp": 129
  },
  {
    "level": 25,
    "exp": 137
  },
  {
    "level": 26,
    "exp": 145
  },
  {
    "level": 27,
    "exp": 153
  },
  {
    "level": 28,
    "exp": 161
  },
  {
    "level": 29,
    "exp": 169
  },
  {
    "level": 30,
    "exp": 178
  },
  {
    "level": 31,
    "exp": 187
  },
  {
    "level": 32,
    "exp": 196
  },
  {
    "level": 33,
    "exp": 205
  },
  {
    "level": 34,
    "exp": 214
  },
  {
    "level": 35,
    "exp": 224
  },
  {
    "level": 36,
    "exp": 234
  },
  {
    "level": 37,
    "exp": 244
  },
  {
    "level": 38,
    "exp": 254
  },
  {
    "level": 39,
    "exp": 264
  },
  {
    "level": 40,
    "exp": 275
  },
  {
    "level": 41,
    "exp": 286
  },
  {
    "level": 42,
    "exp": 297
  },
  {
    "level": 43,
    "exp": 308
  },
  {
    "level": 44,
    "exp": 319
  },
  {
    "level": 45,
    "exp": 331
  },
  {
    "level": 46,
    "exp": 343
  },
  {
    "level": 47,
    "exp": 355
  },
  {
    "level": 48,
    "exp": 367
  },
  {
    "level": 49,
    "exp": 379
  },
  {
    "level": 50,
    "exp": 392
  },
  {
    "level": 51,
    "exp": 405
  },
  {
    "level": 52,
    "exp": 418
  },
  {
    "level": 53,
    "exp": 431
  },
  {
    "level": 54,
    "exp": 444
  },
  {
    "level": 55,
    "exp": 458
  },
  {
    "level": 56,
    "exp": 472
  },
  {
    "level": 57,
    "exp": 486
  },
  {
    "level": 58,
    "exp": 500
  },
  {
    "level": 59,
    "exp": 514
  },
  {
    "level": 60,
    "exp": 529
  },
  {
    "level": 61,
    "exp": 544
  },
  {
    "level": 62,
    "exp": 559
  },
  {
    "level": 63,
    "exp": 574
  },
  {
    "level": 64,
    "exp": 589
  },
  {
    "level": 65,
    "exp": 605
  },
  {
    "level": 66,
    "exp": 621
  },
  {
    "level": 67,
    "exp": 637
  },
  {
    "level": 68,
    "exp": 653
  },
  {
    "level": 69,
    "exp": 669
  },
  {
    "level": 70,
    "exp": 686
  },
  {
    "level": 71,
    "exp": 703
  },
  {
    "level": 72,
    "exp": 720
  },
  {
    "level": 73,
    "exp": 737
  },
  {
    "level": 74,
    "exp": 754
  },
  {
    "level": 75,
    "exp": 772
  },
  {
    "level": 76,
    "exp": 790
  },
  {
    "level": 77,
    "exp": 808
  },
  {
    "level": 78,
    "exp": 826
  },
  {
    "level": 79,
    "exp": 844
  },
  {
    "level": 80,
    "exp": 863
  },
  {
    "level": 81,
    "exp": 882
  },
  {
    "level": 82,
    "exp": 901
  },
  {
    "level": 83,
    "exp": 920
  },
  {
    "level": 84,
    "exp": 939
  },
  {
    "level": 85,
    "exp": 959
  },
  {
    "level": 86,
    "exp": 979
  },
  {
    "level": 87,
    "exp": 999
  },
  {
    "level": 88,
    "exp": 1019
  },
  {
    "level": 89,
    "exp": 1039
  },
  {
    "level": 90,
    "exp": 1060
  },
  {
    "level": 91,
    "exp": 1081
  },
  {
    "level": 92,
    "exp": 1102
  },
  {
    "level": 93,
    "exp": 1123
  },
  {
    "level": 94,
    "exp": 1144
  },
  {
    "level": 95,
    "exp": 1166
  },
  {
    "level": 96,
    "exp": 1188
  },
  {
    "level": 97,
    "exp": 1210
  },
  {
    "level": 98,
    "exp": 1232
  },
  {
    "level": 99,
    "exp": 1254
  },
  {
    "level": 100,
    "exp": 1277
  },
  {
    "level": 101,
    "exp": 1300
  },
  {
    "level": 102,
    "exp": 1323
  },
  {
    "level": 103,
    "exp": 1346
  },
  {
    "level": 104,
    "exp": 1369
  },
  {
    "level": 105,
    "exp": 1393
  },
  {
    "level": 106,
    "exp": 1417
  },
  {
    "level": 107,
    "exp": 1441
  },
  {
    "level": 108,
    "exp": 1465
  },
  {
    "level": 109,
    "exp": 1489
  },
  {
    "level": 110,
    "exp": 1514
  },
  {
    "level": 111,
    "exp": 1539
  },
  {
    "level": 112,
    "exp": 1564
  },
  {
    "level": 113,
    "exp": 1589
  },
  {
    "level": 114,
    "exp": 1614
  },
  {
    "level": 115,
    "exp": 1640
  },
  {
    "level": 116,
    "exp": 1666
  },
  {
    "level": 117,
    "exp": 1692
  },
  {
    "level": 118,
    "exp": 1718
  },
  {
    "level": 119,
    "exp": 1744
  },
  {
    "level": 120,
    "exp": 1771
  },
  {
    "level": 121,
    "exp": 1798
  },
  {
    "level": 122,
    "exp": 1825
  },
  {
    "level": 123,
    "exp": 1852
  },
  {
    "level": 124,
    "exp": 1879
  },
  {
    "level": 125,
    "exp": 1907
  },
  {
    "level": 126,
    "exp": 1935
  },
  {
    "level": 127,
    "exp": 1963
  },
  {
    "level": 128,
    "exp": 1991
  },
  {
    "level": 129,
    "exp": 2019
  },
  {
    "level": 130,
    "exp": 2048
  },
  {
    "level": 131,
    "exp": 2077
  },
  {
    "level": 132,
    "exp": 2106
  },
  {
    "level": 133,
    "exp": 2135
  },
  {
    "level": 134,
    "exp": 2164
  },
  {
    "level": 135,
    "exp": 2194
  },
  {
    "level": 136,
    "exp": 2224
  },
  {
    "level": 137,
    "exp": 2254
  },
  {
    "level": 138,
    "exp": 2284
  },
  {
    "level": 139,
    "exp": 2314
  },
  {
    "level": 140,
    "exp": 2345
  },
  {
    "level": 141,
    "exp": 2376
  },
  {
    "level": 142,
    "exp": 2407
  },
  {
    "level": 143,
    "exp": 2438
  },
  {
    "level": 144,
    "exp": 2469
  },
  {
    "level": 145,
    "exp": 2501
  },
  {
    "level": 146,
    "exp": 2533
  },
  {
    "level": 147,
    "exp": 2565
  },
  {
    "level": 148,
    "exp": 2597
  },
  {
    "level": 149,
    "exp": 2629
  },
  {
    "level": 150,
    "exp": 2662
  }
],

  // 角色仙阶表（共 16 条）
  realmTable: [
  {
    "reqLevel": 1,
    "realmId": 1,
    "name": "小卡拉米",
    "maxAxeQuality": 1,
    "characterImage": "暂略",
    "reqItems": [],
    "icon": ""
  },
  {
    "reqLevel": 10,
    "realmId": 2,
    "name": "中卡拉米",
    "maxAxeQuality": 2,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 1
      },
      {
        "itemId": "4001",
        "count": 1
      },
      {
        "itemId": "5001",
        "count": 1
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 20,
    "realmId": 3,
    "name": "大卡拉米",
    "maxAxeQuality": 2,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 2
      },
      {
        "itemId": "4001",
        "count": 2
      },
      {
        "itemId": "5001",
        "count": 2
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 30,
    "realmId": 4,
    "name": "小修士",
    "maxAxeQuality": 3,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 2
      },
      {
        "itemId": "4001",
        "count": 2
      },
      {
        "itemId": "5001",
        "count": 2
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 40,
    "realmId": 5,
    "name": "中修士",
    "maxAxeQuality": 3,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 2
      },
      {
        "itemId": "4001",
        "count": 2
      },
      {
        "itemId": "5001",
        "count": 2
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 50,
    "realmId": 6,
    "name": "大修士",
    "maxAxeQuality": 3,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 2
      },
      {
        "itemId": "4001",
        "count": 2
      },
      {
        "itemId": "5001",
        "count": 2
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 60,
    "realmId": 7,
    "name": "小飞升",
    "maxAxeQuality": 4,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 3
      },
      {
        "itemId": "4001",
        "count": 3
      },
      {
        "itemId": "5001",
        "count": 3
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 70,
    "realmId": 8,
    "name": "中飞升",
    "maxAxeQuality": 4,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 3
      },
      {
        "itemId": "4001",
        "count": 3
      },
      {
        "itemId": "5001",
        "count": 3
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 80,
    "realmId": 9,
    "name": "大飞升",
    "maxAxeQuality": 4,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 3
      },
      {
        "itemId": "4001",
        "count": 3
      },
      {
        "itemId": "5001",
        "count": 3
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 90,
    "realmId": 10,
    "name": "小神",
    "maxAxeQuality": 5,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 4
      },
      {
        "itemId": "4001",
        "count": 4
      },
      {
        "itemId": "5001",
        "count": 4
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 100,
    "realmId": 11,
    "name": "中神",
    "maxAxeQuality": 5,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 4
      },
      {
        "itemId": "4001",
        "count": 4
      },
      {
        "itemId": "5001",
        "count": 4
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 110,
    "realmId": 12,
    "name": "大神",
    "maxAxeQuality": 5,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 4
      },
      {
        "itemId": "4001",
        "count": 4
      },
      {
        "itemId": "5001",
        "count": 4
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 120,
    "realmId": 13,
    "name": "下仙",
    "maxAxeQuality": 5,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 5
      },
      {
        "itemId": "4001",
        "count": 5
      },
      {
        "itemId": "5001",
        "count": 5
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 130,
    "realmId": 14,
    "name": "中仙",
    "maxAxeQuality": 5,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 5
      },
      {
        "itemId": "4001",
        "count": 5
      },
      {
        "itemId": "5001",
        "count": 5
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 140,
    "realmId": 15,
    "name": "上仙",
    "maxAxeQuality": 5,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 5
      },
      {
        "itemId": "4001",
        "count": 5
      },
      {
        "itemId": "5001",
        "count": 5
      }
    ],
    "icon": ""
  },
  {
    "reqLevel": 150,
    "realmId": 16,
    "name": "大罗金仙",
    "maxAxeQuality": 5,
    "characterImage": "",
    "reqItems": [
      {
        "itemId": "3001",
        "count": 9
      },
      {
        "itemId": "4001",
        "count": 9
      },
      {
        "itemId": "5001",
        "count": 9
      }
    ],
    "icon": ""
  }
],

};

// 根据等级获取本级所需经验
function getExpForLevel(level) {
  const entry = GAME_CONFIG.expTable.find(e => e.level === level);
  return entry ? entry.exp : Math.floor(10 * Math.pow(level, 1.5)); // fallback 公式
}

// 根据 realmId 获取仙阶信息
function getRealmById(realmId) {
  return GAME_CONFIG.realmTable.find(r => r.realmId === realmId);
}

// 根据角色等级获取当前仙阶
function getRealmByLevel(level) {
  let realm = GAME_CONFIG.realmTable[0];
  for (const r of GAME_CONFIG.realmTable) {
    if (level >= r.reqLevel) {
      realm = r;
    }
  }
  return realm;
}

// 根据角色等级获取下一个仙阶
function getNextRealmByLevel(level) {
  for (const r of GAME_CONFIG.realmTable) {
    if (r.reqLevel > level) {
      return r;
    }
  }
  return null;
}
